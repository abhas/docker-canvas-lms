# Initializers

Files in this folder are expected to configure 3rd-party libraries, quite
similarily to Rails initializers.